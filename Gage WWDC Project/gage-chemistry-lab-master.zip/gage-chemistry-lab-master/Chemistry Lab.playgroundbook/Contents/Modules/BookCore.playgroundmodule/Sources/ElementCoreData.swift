//
//  ElementCoreData.swift
//  Chemistry Lab
//
//  Created by 吉乞悠 on 2021/3/24.
//

import Foundation
import UIKit

let coreData = [[  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2],
                [  3,  4,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  5,  6,  7,  8,  9, 10],
                [ 11, 12,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 13, 14, 15, 16, 17, 18],
                [ 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36],
                [ 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54],
                [ 55, 56, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86],
                [ 87, 88,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118],
                [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
                [  0,  0, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70,  0,  0],
                [  0,  0, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99,100,101,102,  0,  0],]

let coreData2 = [[  1,  0,  0,  0,  0,  0,  0,  0,  2],
                 [  3,  4,  0,  5,  6,  7,  8,  9, 10],
                 [ 11, 12,  0,  0,  0,  0,  0,  0,  0,]]

let elementData = [1 : ("H", "Hydrogen", 1), 2 : ("He", "Helium", 4), 3 : ("Li", "Lithium", 7),
                   4 : ("Be", "Beryllium", 9), 5 : ("B", "Boron", 11), 6 : ("C", "Carbon", 12),
                   7 : ("N", "Nitrogen", 14), 8 : ("O", "Oxygen", 16), 9 : ("F", "Fluorine", 19),
                   10: ("Ne", "Neon", 20), 11: ("Na", "Sodium", 23), 12: ("Mg", "Magnesium", 24),
                   13: ("Al", "Aluminum", 27), 14: ("Si", "Silicon", 18), 15: ("P", "Phosphorus", 31),
                   16: ("S", "Sulphur", 32), 17: ("Cl", "Chlorine", 35), 18: ("Ar", "Argon", 40),
                   19: ("K", "Potassium", 39), 20: ("Ca", "Calcium", 40), 21: ("Sc", "Scandium", 45),
                   22: ("Ti", "Titanium", 48), 23: ("V", "Vanadium", 51), 24: ("Cr", "Chromium", 52),
                   25: ("Mn", "Manganese", 55), 26: ("Fe", "Iron", 56), 27: ("Co", "Cobalt", 59),
                   28 : ("Ni", "Nickle", 59), 29 : ("Cu", "Copper", 64), 30 : ("Zn", "Zinc", 65),
                   31 : ("Ga", "Gallium", 70), 32 : ("Ge", "Germanium", 73), 33 : ("As", "Arsenic", 75),
                   34 : ("Se", "Selenium", 79), 35 : ("Br", "Bromine", 79), 36 : ("Kr", "Krypton", 84),
                   37 : ("Rb", "Rubidium", 85), 38 : ("Sr", "Strontium", 88), 39 : ("Y", "Yttrium", 89),
                   40 : ("Zr", "Zirconium", 91), 41 : ("Nb", "Niobium", 93), 42 : ("Mo", "Molybdenum", 96),
                   43 : ("Tc", "Technetium",98), 44 : ("Ru", "Ruthenium", 101), 45 : ("Rh", "Rhodium", 103),
                   46 : ("Pd", "Palladium", 106), 47 : ("Ag", "Silver", 108), 48 : ("Cd", "Cadmium", 112),
                   49 : ("In", "Indium", 115), 50 : ("Sn", "Tin", 119), 51 : ("Sb", "Antimony", 122),
                   52 : ("Te", "Tellurium", 128), 53 : ("I", "Iodine", 127), 54 : ("Xe", "Xenon", 131),
                   55 : ("Cs", "Ceasium", 133), 56 : ("Ba", "Barium", 137), 71 : ("Lu", "Lutetium", 175),
                   72 : ("Hf", "Hafnium", 178), 73 : ("Ta", "Tantalum", 181), 74 : ("W", "Tungsten", 184),
                   75 : ("Re", "Rheniumn", 186), 76 : ("Os", "Osmium", 190), 77 : ("Ir", "Iridium", 192),
                   78 : ("Pt", "Platinum", 195), 79 : ("Au", "Gold", 197), 80 : ("Hg", "Mercury", 201),
                   81 : ("Tl", "Thallium", 204), 82 : ("Pb", "Lead", 207), 83 : ("Bi", "Bismuth", 209),
                   84 : ("Po", "Polonium", 210), 85 : ("At", "Astatine", 210), 86 : ("Rn", "Radon", 220),
                   87 : ("Fr", "Francium", 223), 88 : ("Ra", "Radium", 4), 103  : ("Lr", "Lawrencium", 262),
                   104 : ("Rf", "Rutherfordium", 261), 105 : ("Db", "Dubnium", 262), 106 : ("Sg", "Seabergium", 266),
                   107 : ("Bh", "Bohrium", 264), 108 : ("Hs", "Hassium", 277), 109 : ("Mt", "Meitnerium", 268),
                   110 : ("Ds", "Darmstadium", 271), 111 : ("Rg", "Roentgenium", 272), 112 : ("Cn", "Copernicium", 285),
                   113 : ("Uut", "Ununtrium", 284), 114 : ("Fl", "Flerovium", 289), 115 : ("Uup", "Ununpentium", 288),
                   116 : ("Lv", "Livermorium", 292), 117 : ("Uus", "Ununseptium", 0), 118 : ("294", "Ununoctium", 294),
                   57 : ("La", "Lathanum", 139), 58 : ("Ce", "Cerium", 140), 59 : ("Pr", "Prasepdymium", 141),
                   60 : ("Nd", "Neodymium", 144), 61 : ("Pm", "Promethium", 145), 62 : ("Sm", "Samarium", 150),
                   63 : ("Eu", "Europium", 152), 64 : ("Gd", "Gadolinium", 157), 65 : ("Tb", "Terbium", 159),
                   66 : ("Dy", "Dysprosium", 163), 67 : ("Ho", "Holmium", 165), 68 : ("Er", "Erbium", 167),
                   69 : ("Tm", "Thulium", 169), 70 : ("Yb", "Ytterbium", 173), 89 : ("Ac", "Actnium", 227),
                   90 : ("Th", "Thorium", 232), 91 : ("Pa", "Proactium", 231), 92 : ("U", "Uranium", 238),
                   93 : ("Np", "Neptanium", 237), 94 : ("Pu", "Plutonium", 244), 95 : ("Am", "Americium", 243),
                   96 : ("Cm", "Curium", 247), 97 : ("Bk", "Berlleium", 247), 98 : ("Cf", "Califorium", 251),
                   99 : ("Es", "Einsteinium", 252), 100 : ("Fm", "Fermium", 257), 101 : ("Md", "Mendelvium", 258),
                   102 : ("No", "Nobelium", 259)]

let elementGroup = [1 : [3,11,19,37,55,87],
                    2 : [4,12,20,38,56,88],
                    3 : [21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 39, 40, 41, 42,
                         43, 44, 45, 46, 47, 48, 71, 72, 73, 74, 75, 76, 77, 78,
                         79, 80, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112],
                    4 : [13,31,49,50,81,82,83],
                    5 : [5,14,32,33,51,52,84],
                    6 : [1,6,7,8,15,16,34],
                    7 : [9,17,35,53,85],
                    8 : [2,10,18,36,54,86],
                    9 : [113,114,115,116,117,118],
                   10 : [57,58,59,60,61,62,63,64,65,66,67,68,69,70],
                   11 : [89,90,91,92,93,94,95,96,97,98,99,100,101,102]]

let elementGroupColor = [1 : UIColor(red: 248/255, green: 184/255, blue: 127/255, alpha: 1),
                         2 : UIColor(red: 251/255, green: 217/255, blue: 127/255, alpha: 1),
                         3 : UIColor(red: 232/255, green: 255/255, blue: 127/255, alpha: 1),
                         4 : UIColor(red: 253/255, green: 250/255, blue: 127/255, alpha: 1),
                         5 : UIColor(red: 132/255, green: 217/255, blue: 142/255, alpha: 1),
                         6 : UIColor(red: 154/255, green: 119/255, blue: 255/255, alpha: 1),
                         7 : UIColor(red: 254/255, green: 117/255, blue: 255/255, alpha: 1),
                         8 : UIColor(red: 129/255, green: 215/255, blue: 255/255, alpha: 1),
                         9 : UIColor.lightGray,
                        10 : UIColor(red: 202/255, green: 255/255, blue: 126/255, alpha: 1),
                        11 : UIColor(red: 172/255, green: 255/255, blue: 127/255, alpha: 1)]

// 1) C H O Na Cl
//    能组合成哪些物质？
//    以及这些物质的介绍。
// 2) 元素周期表中每个Group的介绍
//    挑一些掉落下来的元素，找一段介绍
//    介绍都不用超过3、4句话

// C H O Na Cl Fe
