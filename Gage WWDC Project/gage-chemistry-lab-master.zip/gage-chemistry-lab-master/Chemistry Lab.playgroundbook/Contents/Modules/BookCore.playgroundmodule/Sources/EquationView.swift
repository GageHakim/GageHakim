//
//  EquationView.swift
//  Chemistry Lab
//
//  Created by 吉乞悠 on 2021/3/31.
//

import UIKit

class EquationView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .systemPink
        
        let framImageView = UIImageView(image: UIImage(named: "frame"))
        framImageView.frame = CGRect(x: 13, y: 13, width: 128, height: 128)
        addSubview(framImageView)
        
        let plusImageView = UIImageView(image: UIImage(named: "plus"))
        plusImageView.frame = CGRect(x: 150, y: 30, width: 90, height: 90)
        addSubview(plusImageView)
        
        let framImageView2 = UIImageView(image: UIImage(named: "frame"))
        framImageView2.frame = CGRect(x: 243, y: 13, width: 128, height: 128)
        addSubview(framImageView2)
        
        let plusImageView2 = UIImageView(image: UIImage(named: "plus"))
        plusImageView2.frame = CGRect(x: 380, y: 30, width: 90, height: 90)
        addSubview(plusImageView2)
        
        let framImageView3 = UIImageView(image: UIImage(named: "frame"))
        framImageView3.frame = CGRect(x: 490, y: 13, width: 128, height: 128)
        addSubview(framImageView3)
        
        let equalImageView = UIImageView(image: UIImage(named: "equals"))
        equalImageView.frame = CGRect(x: 640, y: 13, width: 128, height: 128)
        addSubview(equalImageView)
        
        let questionImageView = UIImageView(image: UIImage(named: "unknown"))
        questionImageView.frame = CGRect(x: 800, y: 13, width: 128, height: 128)
        addSubview(questionImageView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
