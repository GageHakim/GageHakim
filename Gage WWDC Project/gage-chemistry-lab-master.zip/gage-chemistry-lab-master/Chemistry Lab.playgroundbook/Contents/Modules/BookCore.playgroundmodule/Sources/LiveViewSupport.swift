//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import PlaygroundSupport

/// Instantiates a new instance of a live view.
///
/// By default, this loads an instance of `LiveViewController` from `LiveView.storyboard`.
public func instantiateLiveView() -> PlaygroundLiveViewable {
    return MyLiveViewController()
}

public func instantiatePart1iewController() -> PlaygroundLiveViewable {
    return Part1ViewController()
}

public func instantiatePart2iewController() -> PlaygroundLiveViewable {
    return Part2ViewController()
}

public func instantiatePart3ViewController() -> PlaygroundLiveViewable {
    return Part3ViewController()
}
