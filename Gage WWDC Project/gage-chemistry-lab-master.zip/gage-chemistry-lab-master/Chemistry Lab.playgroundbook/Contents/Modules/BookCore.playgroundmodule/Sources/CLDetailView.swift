//
//  CLDetailView.swift
//  Chemistry Lab
//
//  Created by 吉乞悠 on 2021/4/6.
//

import UIKit

class CLDetailView: UIView {

    init(frame: CGRect, str: String) {
        super.init(frame: frame)
        
        self.frame.size = CGSize(width: 400, height: 400)
        layer.cornerRadius = 24
        
        backgroundColor = .white
        
        let titleImage = UILabel()
        titleImage.textColor = UIColor.darkGray
        titleImage.font = UIFont.systemFont(ofSize: 52)
        titleImage.attributedText = setString(str: str)
        titleImage.sizeToFit()
        titleImage.center = CGPoint(x: self.frame.width / 2, y: 50)
        addSubview(titleImage)
        
        let detailImage = UIImageView()
        detailImage.contentMode = .scaleAspectFit
        detailImage.image = UIImage(named: str)
        detailImage.frame.size = CGSize(width: 150, height: 150)
        detailImage.backgroundColor = .white
        detailImage.center = CGPoint(x: self.frame.width / 2, y: 170)
        addSubview(detailImage)
        
        let detailLabel = UILabel()
        detailLabel.text = EDetailDict[str]
        detailLabel.font = UIFont.systemFont(ofSize: 18)
        detailLabel.textColor = UIColor.darkGray
        detailLabel.frame.size = CGSize(width: 360, height: 130)
        detailLabel.center = CGPoint(x: self.frame.width / 2, y: 325)
        detailLabel.numberOfLines = 0
        detailLabel.backgroundColor = .white
        addSubview(detailLabel)
        
    }
    
    func setString(str: String) -> NSMutableAttributedString {
        func setChar(i: Int) {
            if str[str.index(str.startIndex, offsetBy: i)].isNumber {
                attrStr.addAttributes([.font : UIFont.systemFont(ofSize: 32)], range: NSRange(location: i, length: 1))
            }
        }
        
        let attrStr = NSMutableAttributedString(string: str)
        for i in 0...str.count - 1 { setChar(i: i) }
        return attrStr
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
