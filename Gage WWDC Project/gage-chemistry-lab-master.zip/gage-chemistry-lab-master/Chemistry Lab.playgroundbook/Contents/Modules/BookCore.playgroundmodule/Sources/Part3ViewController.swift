//
//  Part3ViewController.swift
//  Chemistry Lab
//
//  Created by 吉乞悠 on 2021/3/31.
//

import UIKit
import PlaygroundSupport

public enum Element: Int {
    case None = 0
    case C = 6
    case H = 1
    case O = 8
    case Na = 11
    case Cl = 17
}

public class Part3ViewController: BaseVC {
    
    var scView: SixCardView!
    var pushedView: CLDetailView!
    
    public var es: [Element] = [.None, .None, .None]
    
//    public override func viewDidLoad() {
//        super.viewDidLoad()
//        setElement1(.C)
//        setElement2(.C)
//        setElement3(.None)
//        go()
//    }
    
    public func setElement1(_ e: Element) {
        es[0] = e
    }
    
    public func setElement2(_ e: Element) {
        es[1] = e
    }
    
    public func setElement3(_ e: Element) {
        es[2] = e
    }
    
    public func go() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [self] in
            let newEC = es.filter({ (e) -> Bool in
                return e != .None
            })
            if newEC.isEmpty {
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["Please use more than two elements!"], solution: nil);
                return
            }
            
            scView = SixCardView(elements: newEC)
            scView.center = view.center
            view.addSubview(scView)
            
            pushedView = CLDetailView(frame: CGRect(), str: check(newEC))
            pushedView.center = view.center
            pushedView.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
            view.addSubview(pushedView)
            pushedView.alpha = 0
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [self] in
                rotate()
                scale()
            }
        }
    }
    
    func check(_ ec: [Element]) -> String {
        var d = ec
        d.sort { (a, b) -> Bool in
            a.rawValue > b.rawValue
        }
        for c in ElementDict {
            var a = c.value
            a.sort { (a, b) -> Bool in
                a.rawValue > b.rawValue
            }
            if d == a {
                return c.key
            }
        }
        return "Oh No!"
    }
    
    public func rotate() {
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveLinear) { [self] in
            scView.transform = CGAffineTransform(rotationAngle: CGFloat.pi)
        } completion: { (isFinshed) in
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveLinear) { [self] in
                scView.transform = scView.transform.rotated(by: CGFloat.pi)
            } completion: { (isFinshed) in
                UIView.animate(withDuration: 0.3, delay: 0, options: .curveLinear) { [self] in
                    scView.transform = scView.transform.rotated(by: CGFloat.pi)
                } completion: { (isFinshed) in
                    UIView.animate(withDuration: 0.3, delay: 0, options: .curveLinear) { [self] in
                        scView.transform = scView.transform.rotated(by: CGFloat.pi)
                        scView.alpha = 0
                    } completion: { (isFinshed) in
                        self.scView.removeFromSuperview()
                    }
                }
            }
        }
    }
    
    public func scale() {
        UIView.animate(withDuration: 1.1) { [self] in
            scView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        } completion: { (isFinished) in
            self.pushImage()
        }
    }
    
    public func pushImage() {
        pushedView.alpha = 1
        UIView.animate(withDuration: 0.6) { [self] in
            pushedView.transform = .identity
        } completion: { (isFinished) in
            
        }
    }
    
}

let ElementDict: [String : [Element]] = ["H2O" : [.H, .H, .O], "O3" : [.O, .O, .O], "O2" : [.O, .O], "NaH" : [.H, .Na], "CO2" : [.C, .O, .O],
                                         "CO" : [.C, .O], "NaO" : [.Na, .O], "ClO" : [.Cl, .O], "NaCl" : [.Cl, .Na], "H2" : [.H, .H], "HCl" : [.H, .Cl]]

let EDetailDict: [String : String] =
    ["Oh No!" : "Please try again, and if you need help, you can find it in the CheatSheet.swift file in UserModules.",
     
     "NaH" : "Sodium Hydride, this compound will attack silicon and thus is used in the medical industry.",

     "CO2" : "Carbon dioxide, a colourless gas that is a big player in greenhouse gases and is also what our bodies exhale.",

     "CO" : "Carbon Monoxide, a colorless and flammable gas that is dangerous if concentrated enough which is oftener used in manufacturing chemical products.",

     "NaO" : "Sodium oxide, this is a material usually used in the manufacturing of glass.",

     "ClO" : "Chlorine Monoxide, this a red-yellow gas that is a big player in ozone depletion which is a part of the cycle where ozone is created then depleted.",

     "NaCl" : "Sodium chloride, or more commonly known as salt can be a seasoning in cooking if there is some processing which is usually found in oceans. It can also appear in your body absorbing and transporting nutrients.",

     "O2" : "Oxygen gas, or more commonly known as just oxygen is an essential resource to all life, allowing us to respire. It also can oxidise substances. It is also a key requirement in most combustion.",

     "O3" : "Ozone, is most commonly found in the ozone layer absorbing the ultraviolet radiation the sun. It can also be used as a disinfectant and much more.",

     "H2" : "Hydrogen gas, or more commonly known as just hydrogen is a highly flammable colorless gas. It is also known to be used in petroleum refineries and much more.",
    
     "H2O" : "Dihydrogen Monoxide, or more commonly known as water is the essential resource to all living organisms. It is extremely abundant on earth and fills the seas, lakes, river, and Oceans.",
    
     "HCl" : "Hydrochloric acid is one of the most important fluids in the human body. It is apart of the digestion fluid in your stomach and also is commonly used for lab experiments."]
