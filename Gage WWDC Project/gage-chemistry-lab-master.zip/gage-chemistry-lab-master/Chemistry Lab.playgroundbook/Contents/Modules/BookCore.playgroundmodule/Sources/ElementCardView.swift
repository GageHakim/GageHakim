//
//  ElementCardView.swift
//  Chemistry Lab
//
//  Created by 吉乞悠 on 2021/3/16.
//

import UIKit

class ElementCardData {
    var atomicNumber: Int
    var title: String?
    var atomicMass: Int?
    var name: String?
    var groupColor: UIColor?
    
    init(atomicNumber: Int) {
        self.atomicNumber = atomicNumber
        let detail = getDetailWith(atomicNumber: atomicNumber)
        title = detail.0
        name = detail.1
        atomicMass = detail.2
        groupColor = detail.3
    }
    
    func getDetailWith(atomicNumber: Int) -> (String, String, Int, UIColor) {
        let data = elementData[atomicNumber] ?? ("H", "Hydrogen", 1)
        var color = UIColor.orange
        for item in elementGroup {
            if item.value.contains(atomicNumber) {
                color = elementGroupColor[item.key] ?? .orange
            }
        }
        return (data.0, data.1, data.2, color)
    }
}

class ElementCardView: UIView {
    
    var data: ElementCardData? {
        didSet {
            elementTitle.text = data?.title
            atomicMassTitle.text = "\(data!.atomicMass!)"
            atomicNumberTitle.text = "\(data!.atomicNumber)"
            elementNameTitle.text = data?.name
            backgroundColor = data?.groupColor
        }
    }
    
    let elementTitle = UILabel()
    let atomicMassTitle = UILabel()
    let atomicNumberTitle = UILabel()
    let elementNameTitle = UILabel()
    
    func hideDetails() {
        atomicMassTitle.isHidden = true
        atomicNumberTitle.isHidden = true
        elementNameTitle.isHidden = true
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let edge = frame.width
        
        backgroundColor = .systemGreen
        layer.borderWidth = 0.01 * edge
        layer.borderColor = UIColor.black.cgColor
        
        elementTitle.font = UIFont.systemFont(ofSize: 0.4 * edge, weight: .medium)
        elementTitle.text = "WWW"
        elementTitle.sizeToFit()
        elementTitle.textAlignment = .center
        elementTitle.center = CGPoint(x: frame.width / 2,
                                      y: frame.height / 2)
        addSubview(elementTitle)
        
        atomicMassTitle.font = UIFont.systemFont(ofSize: 0.13 * edge, weight: .regular)
        atomicMassTitle.text = "888"
        atomicMassTitle.sizeToFit()
        atomicMassTitle.textAlignment = .right
        atomicMassTitle.frame.origin = CGPoint(x: frame.width - 0.08 * edge - atomicMassTitle.frame.width, y: 0.07 * edge)
        addSubview(atomicMassTitle)
        
        atomicNumberTitle.font = UIFont.systemFont(ofSize: 0.21 * edge, weight: .regular)
        atomicNumberTitle.text = "888"
        atomicNumberTitle.sizeToFit()
        atomicNumberTitle.textAlignment = .left
        atomicNumberTitle.frame.origin = CGPoint(x: 0.08 * edge, y: 0.05 * edge)
        addSubview(atomicNumberTitle)
        
        elementNameTitle.font = UIFont.systemFont(ofSize: 0.16 * edge, weight: .regular)
        elementNameTitle.text = "WWWWWWWWWW"
        elementNameTitle.sizeToFit()
        elementNameTitle.textAlignment = .center
        elementNameTitle.center = CGPoint(x: frame.width / 2, y: frame.height * 0.8)
        addSubview(elementNameTitle)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
