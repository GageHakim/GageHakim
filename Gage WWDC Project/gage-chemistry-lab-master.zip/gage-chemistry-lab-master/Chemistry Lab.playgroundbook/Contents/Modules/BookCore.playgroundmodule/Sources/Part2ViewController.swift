//
//  Part2ViewController.swift
//  BookCore
//
//  Created by 吉乞悠 on 2021/4/18.
//

import UIKit
import PlaygroundSupport

class Part2ViewController: DynamicPanViewController {
    
    var SCREENWIDTH: CGFloat = 0
    var SCREENHEIGHT: CGFloat = 0
    
    var targetCardsNumber = [0, 1, 7, 10, 16, 25]
    
    var cards:  [ElementCardView] = []
    var eCards: [ElementCardView] = []
    var targetECards: [ElementCardView] = []
    
    var targetRects: [CGRect] = []
    
    var correctCounter = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
            SCREENWIDTH = view.frame.width
            SCREENHEIGHT = view.frame.height
            
            contentView = UIView(frame: CGRect(x: 0, y: 0, width: SCREENWIDTH, height: SCREENHEIGHT - 70))
            contentView.backgroundColor = .clear
            view.addSubview(contentView)
            animator = UIDynamicAnimator(referenceView: contentView)
            
            let cardEdge = SCREENWIDTH / 18
            
            for i in 0...coreData.count - 1 {
                for j in 0...coreData[0].count - 1 {
                    let elementCard = ElementCardView(frame: CGRect(x: CGFloat(j) * cardEdge,
                                                                    y: 44 + CGFloat(i) * cardEdge,
                                                                    width: cardEdge, height: cardEdge))
                    if coreData[i][j] != 0 {
                        contentView.addSubview(elementCard)
                        eCards.append(elementCard)
                    }
                    
                    elementCard.data = ElementCardData(atomicNumber: coreData[i][j])
                    cards.append(elementCard)
                }
            }
            
            for number in targetCardsNumber {
                targetECards.append(eCards[number])
            }
            
                for i in 0...targetECards.count - 1 {
                    contentView.bringSubviewToFront(targetECards[i])
                    targetECards[i].hideDetails()
                    targetRects.append(targetECards[i].frame)
                    targetECards[i].tag = i + 100
                }
                
                setupDynamicItems(items: targetECards)
        }
        
    }
    
    override func getLastPosition(origin: CGPoint, tag: Int) {
        let viewTag = tag - 100
        let targetRect = targetRects[viewTag]
        if targetRect.contains(origin) {
            print(viewTag)
            snapViewToRect(view: targetECards[viewTag], rect: targetRect)
            correctCounter += 1
            if correctCounter == 6 {
                PlaygroundPage.current.assessmentStatus = .pass(message: "Great job! You can go to the next level and do some experiments!")
            }
        } else {
            // Fail
        }
    }
    
}
