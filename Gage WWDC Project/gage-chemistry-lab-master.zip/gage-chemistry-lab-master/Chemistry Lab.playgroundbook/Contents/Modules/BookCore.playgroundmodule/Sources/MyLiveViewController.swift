//
//  MyLiveViewController.swift
//  BookCore
//
//  Created by 吉乞悠 on 2021/4/17.
//

import UIKit

class MyLiveViewController: BaseVC {
    var cards: [ElementCardView] = []
    
    var w: CGFloat = 0
    var h: CGFloat = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
            w = view.frame.width
            h = view.frame.height
            
            let cardEdge: CGFloat = 60

            for i in 1...36 {
                let elementCard = ElementCardView(frame: CGRect(x: CGFloat.random(in: 0...w),
                                                                y: CGFloat.random(in: 0...h),
                                                                width: cardEdge, height: cardEdge))
                elementCard.data = ElementCardData(atomicNumber: i)
                cards.append(elementCard)
                
                view.addSubview(elementCard)
                
                setMotion(c: elementCard)
            }
        }
    }
    
    func setMotion(c: UIView) {
        UIView.animate(withDuration: TimeInterval.random(in: 8...14),
                       delay: 0,
                       options: .curveLinear) { [self] in
            c.transform = CGAffineTransform(rotationAngle: CGFloat.random(in: 0...CGFloat.pi))
            c.center = CGPoint(x: CGFloat.random(in: 0...w), y: CGFloat.random(in: 0...h))
        } completion: { (iF) in
            self.setMotion(c: c)
        }

    }

}
