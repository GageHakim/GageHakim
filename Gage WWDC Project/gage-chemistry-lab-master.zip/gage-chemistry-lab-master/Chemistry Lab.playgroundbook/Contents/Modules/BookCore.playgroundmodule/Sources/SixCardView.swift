//
//  SixCardView.swift
//  Chemistry Lab
//
//  Created by 吉乞悠 on 2021/4/11.
//

import UIKit

class SixCardView: UIView {
    
    var targetCardsNumber = [1, 2, 6, 8, 11, 17]

    init(elements: [Element]) {
        super.init(frame: CGRect())

        targetCardsNumber = []
        for e in elements {
            targetCardsNumber.append(e.rawValue)
        }
        
        let cardEdge:CGFloat = 80
        
        frame.size = CGSize(width: CGFloat(elements.count) * cardEdge, height: cardEdge)
        
        for i in 0...elements.count - 1 {
            let elementCard = ElementCardView(frame: CGRect(x: CGFloat(i) * cardEdge,
                                                            y: 0,
                                                            width: cardEdge, height: cardEdge))
            
            elementCard.data = ElementCardData(atomicNumber: targetCardsNumber[i])
            addSubview(elementCard)
            
        }
        
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
}
