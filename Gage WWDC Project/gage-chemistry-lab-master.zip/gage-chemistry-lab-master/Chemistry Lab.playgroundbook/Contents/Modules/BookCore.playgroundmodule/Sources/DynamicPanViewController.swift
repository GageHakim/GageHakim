//
//  DynamicPanViewController.swift
//  Chemistry Lab
//
//  Created by 吉乞悠 on 2021/4/7.
//

import UIKit

class DynamicPanViewController: BaseVC {
    
    var animator:      UIDynamicAnimator!
    var gravity:       UIGravityBehavior!
    var collision:     UICollisionBehavior!
    var itemBehaviour: UIDynamicItemBehavior!
    
    var snap:          UISnapBehavior!
    
    var dynamicItems:  [UIView] = []
    
    var contentView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    func setupDynamicItems(items: [UIView]) {
        dynamicItems = items
        
        gravity = UIGravityBehavior(items: items)
        animator.addBehavior(gravity)
        
        itemBehaviour = UIDynamicItemBehavior(items: items)
        itemBehaviour.elasticity = 0
        itemBehaviour.friction = 8
        itemBehaviour.density = 1000
        itemBehaviour.resistance = 2
        itemBehaviour.angularResistance = 10
        animator.addBehavior(itemBehaviour)
        
        collision = UICollisionBehavior(items: items)
        collision.translatesReferenceBoundsIntoBoundary = true
        animator.addBehavior(collision)
        
        for i in 0...items.count - 1 {
            let pan = UIPanGestureRecognizer(target: self, action: #selector(pan(recognizer:)))
            items[i].addGestureRecognizer(pan)
            items[i].layer.borderWidth = 2
            items[i].layer.borderColor = UIColor.darkGray.cgColor
        }
    }
    
    var cardOrigin: CGPoint = CGPoint()
    
    @objc func pan(recognizer: UIPanGestureRecognizer) {
        if (snap != nil) { animator.removeBehavior(snap) }
        if recognizer.state == .began {
            recognizer.view!.layer.borderColor = UIColor.orange.cgColor
            
            cardOrigin = recognizer.view!.center
        } else if recognizer.state == .changed {
            let targetOrigin = CGPoint(x: cardOrigin.x + recognizer.translation(in: contentView).x,
                                       y: cardOrigin.y + recognizer.translation(in: contentView).y)
            snap = UISnapBehavior(item: recognizer.view!, snapTo: targetOrigin)
            animator.addBehavior(snap)
        } else if recognizer.state == .ended {
            recognizer.view!.layer.borderColor = UIColor.darkGray.cgColor
            
            if (gravity != nil) { animator.removeBehavior(gravity) }
            gravity = UIGravityBehavior(items: dynamicItems)
            animator.addBehavior(gravity)

            let targetOrigin = CGPoint(x: cardOrigin.x + recognizer.translation(in: contentView).x,
                                       y: cardOrigin.y + recognizer.translation(in: contentView).y)
            getLastPosition(origin: targetOrigin, tag: recognizer.view!.tag)
        }
    }
    
    func getLastPosition(origin: CGPoint, tag: Int) {
        
    }
    
    func snapViewToRect(view: UIView, rect: CGRect) {
        view.layer.borderColor = UIColor.green.cgColor
        let targetOrigin = CGPoint(x: rect.origin.x + rect.size.width / 2, y: rect.origin.y + rect.size.height / 2)
        snap = UISnapBehavior(item: view, snapTo: targetOrigin)
        animator.addBehavior(snap)
        view.removeGestureRecognizer(view.gestureRecognizers!.first!)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [self] in
            animator.removeAllBehaviors()
            dynamicItems.remove(at: dynamicItems.firstIndex(of: view)!)
            gravity = UIGravityBehavior(items: dynamicItems)
            animator.addBehavior(gravity)
            
            itemBehaviour = UIDynamicItemBehavior(items: dynamicItems)
            itemBehaviour.elasticity = 0
            itemBehaviour.friction = 8
            itemBehaviour.density = 1000
            itemBehaviour.resistance = 2
            itemBehaviour.angularResistance = 10
            animator.addBehavior(itemBehaviour)
            
            collision = UICollisionBehavior(items: dynamicItems)
            collision.translatesReferenceBoundsIntoBoundary = true
            animator.addBehavior(collision)
        }
    }

}

extension UIView {
    func asImage() -> UIImage {
        let f = UIGraphicsImageRendererFormat()
        let renderer = UIGraphicsImageRenderer(bounds: bounds, format: f)
        
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
}
