//
//  Extension.swift
//  BookCore
//
//  Created by 吉乞悠 on 2021/4/18.
//


import UIKit

public class BaseVC: UIViewController {
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        let image = UIImageView(image: UIImage(named: "ooo.jpg"))
        image.contentMode = .scaleAspectFill
        image.frame = view.frame
        view.addSubview(image)
    }
    
}
