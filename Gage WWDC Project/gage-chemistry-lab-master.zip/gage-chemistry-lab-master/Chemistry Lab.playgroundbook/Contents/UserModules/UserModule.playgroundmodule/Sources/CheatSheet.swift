// Here is the cheat sheet!!!
//
// You can find all the combinations here!
//
//
// [.H, .H, .O] -> "H2O"
// [.O, .O, .O] -> "O3"
// [.O, .O]     -> "O2"
// [.H, .Na]    -> "NaH"
// [.C, .O, .O] -> "CO2"
// [.C, .O]     -> "CO"
// [.Na, .O]    -> "NaO"
// [.Cl, .O]    -> "ClO"
// [.Cl, .Na]   -> "NaCl"
// [.H, .H]     -> "H2"
// [.H, .Cl]    -> "HCl"
