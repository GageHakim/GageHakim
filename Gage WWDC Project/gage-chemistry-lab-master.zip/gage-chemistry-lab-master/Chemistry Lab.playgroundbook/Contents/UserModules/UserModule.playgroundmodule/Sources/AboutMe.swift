//
//  AboutMe.swift
//
//

let myName = "Gage Hakim"
let myAge = "12"

let aboutMe = """
My name is Gage Hakim and I got into technology at a very early stage of my life (I am currently 12). I am a mixed child from around 4 countries so I have been able to live around all of the major technological advancements since I was a child. I got my first electronic device (which was an iPad 2) for my fourth birthday and have loved technology ever since. I remember starting to program in second grade. I was learning to program Scratch with some of my friends and it gave me all the basics that I needed for furthering my programming capabilities. I then started to learn about the python coding language in 3rd grade and actually started the Minecraft python class at around 4th grade which was when I decided to actually decide to dedicate myself to coding. At about this time I also started to learn unity with this very nice Korean teacher over the summer break and slowly but surely attended an online class for C# and all was going in a great direction. In 5th grade, I went to this maker space in Shenzhen called MG and the teachers there taught me the way around 3d printers, laser cutters, and most importantly Arduino.

Then finally at the end of 6th grade, after Covid slowly dissipated in China, I learned Swift, the coding language in my opinion that would outshine the others that I had learned. Swift started as a way to actually understand how and why an APP worked as it did, and just a bit later, I really started to dedicate my time to swift and found out that there was this competition about it. Then, because of my passion for Swift, I joined in and I started taking more classes and made this program. I have so far spent around a year and plan on spending a lot more time dedicated to Swift.

I am currently extremely happy with how this turned out but at the same time kind of excepted it. Our family more or less only uses Apple products for technology and I’ve also had plenty of personal ties to it like my first phone (an iPhone 6), my current one (an iPhone 12), and my laptop (a book pro). If years of technology did not leave me disappointed, then why would Apple’s developer coding language leave me disappointed?

Anyhow, enough of my rambling, I hope you enjoy the playground I made!
"""
