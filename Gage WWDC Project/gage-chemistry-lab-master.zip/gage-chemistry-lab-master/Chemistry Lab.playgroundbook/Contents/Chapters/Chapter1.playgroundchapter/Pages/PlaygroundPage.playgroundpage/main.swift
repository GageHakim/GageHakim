//#-hidden-code
import UIKit
import PlaygroundSupport
import BookCore

PlaygroundPage.current.liveView = BookCore.instantiatePart1iewController()
let str = "Hello, playground"
//#-end-hidden-code
/*:
 # Introduction
 
 The periodic table is an organized array of all of the known elements in the world arranged in order by their protons. The aforementioned word elements is actually what the whole world is made of. Everything you interact with is made out of 2 or multiple elements combined to form compounds that everything you can imagine is made out of. A bit confused right?

 Well don’t you worry because the playground I am presenting today will help you with that and also teach you the basics of chemistry.
 
 **Quick Note:** This section is best experienced full screen so if you want the full experience then use full screen.
 
 ### Alkali Metals
 
 Elements of the alkali metals group are all soft, shiny, and have a silver tint. They are also radioactive at room temperature.
 
 ### Alkaline Earth Metals

 Elements of the alkaline earth metals group all have low boiling and melting points which mean they are easy to melt or boil into a gas or liquid form. They are semi-radioactive at room temperature also have a shiny and silvery tint.
 
 ### Transition Metals

 The elements that are transition metals all have high bowling and melting points which means they need a very high temperature to change their state. They can also conduct electricity and heat very well. And they also have high densities and are very hard.
 
 ### Non-Metal

 The elements of the non-metal group are all brittle and have little to no metallic shine. They are also terrible at conducting electricity and heat. They are not classified as what they have combined and rather they are classified because they are not metals so they usually won’t have anything too special.
 
 ### Noble Gases

 The elements of the noble gases group are the stable element group as they have a full outer shell. They almost never have reactions with other elements and are gases. They are usually gases and have a low melting and boiling point.
 
 ### Other Metals

 The elements of the other metals group are all solid under room temperature and are malleable which means it is easy to shape without it breaking. They are good at conducting electricity and heat. They are also usually opaque.
 
 ### Halogens

 The elements of the halogens group are highly reactive lethal when reacted upon. They all have low boiling and melting points. They are all highly reactive and radioactive.
 
 ### Metalloid

 The elements of the metalloid group are semi-conductors of both electricity and heat which means that they can transfer heat and electricity but it will not be as well as normal metals. The metalloids are called their name because they fall I between the metals and the non-metals  but they actually share most of their traits with the non-metals.
 
 ### Actinides

 The elements of the actinides group are all radioactive elements that do not have a long half-life which means they half their concentration in a very short amount of time. They all have a silvery white color with high densities.
 
 ### Lanthanides

 The elements of the Lanthanides group are all silvery white coloured metals that are reactive. The main reason why they are grouped together is because they are consecutive metals in the periodic table that all share the same properties with one another.
 */
