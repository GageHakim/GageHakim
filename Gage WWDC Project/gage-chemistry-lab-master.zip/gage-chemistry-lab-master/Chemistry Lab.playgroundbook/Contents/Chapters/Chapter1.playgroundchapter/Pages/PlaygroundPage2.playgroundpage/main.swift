//#-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, None, C, H, O, Na, Cl)
import UIKit
import PlaygroundSupport
import BookCore

let ChemistryLab = instantiatePart3ViewController() as! Part3ViewController
PlaygroundPage.current.liveView = ChemistryLab
//#-end-hidden-code
/*:
 # Lab
 
 In this level, you will be able to experiment with combining different elements to see if you can make a compound. You can think of it as a lab where you can use trial and error. However, if you are in a rush or are having a get stuck, there is a cheat located toward the bottom left of your screen.
 
 You can combine elements by taping on the dimly illuminated parts of the code. Once you click on a part, there should be a few symbols at the very bottom. Those can act as buttons and they refer to different elements that you will be experimenting with. If you want to try to create a compound with two elements, there should be a “none” button there which you can use.
 */
ChemistryLab.setElement1(Element.<#element#>)
ChemistryLab.setElement2(Element.<#element#>)
ChemistryLab.setElement3(Element.<#element#>)
//#-hidden-code
ChemistryLab.go()
//#-end-hidden-code
