//#-hidden-code
import UIKit
import PlaygroundSupport
import BookCore

PlaygroundPage.current.liveView = BookCore.instantiatePart2iewController()
let str = "Hello, playground"
//#-end-hidden-code
/*:
 # Puzzle
 
 In this page, after you click “Run My Code”, some elements will randomly drop down and you will have to put them back to where they came from by reading their descriptions below this text and combine them with what you learned last level. You will have to drag and drop them to their original position and if you get all of them, you get to go onto the [next level](@next).
 
 **Quick Note:** This section is best experienced full screen so if you want the full experience then use full screen.
 
 ### H
 
 Hydrogen is a element of column 1 and is a non-metal. It is the most abundant element in the universe and is also the lightest element. It is most normally found in water and in hydrogen gas.

 ### C
 
 Carbon is a element of column 14 and is a non-metal. It is naturally abundant and is apparent in all organic compounds. Though it is widely spread it only makes up a little under 0.0025 percent of the earth’s crust.
 
 ### O
 
 Oxygen is an element of column 16 and is a non-metal. It is highly reactive and can group into oxygen gas which is one of the most fundamental building blocks of human survival. It is the third most abundant resource in the universe and can almost always be found bonded with another element due to its high reactivity.
 
 ### Na
 
 Sodium is an element of column 1 and is an alkali metal. It does not freely appear in nature freely as a metal and rather has to be extracted from other compounds of itself. It is the 6th most abundant material in the earth’s crust and is most commonly found in salt.
 
 ### Fe
 
 Iron is a transition metal located column 8 and has a high melting and boiling point. It looks metallic and is solid at room temperature.
 
 ### He
 
 Helium is a noble gas in column 18 that is extremely not reactive. It is the second lightest gas in the world and it has the lowest boiling point out of all of the elements.

 */
